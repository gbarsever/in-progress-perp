Version history
===============

0.2.1 (Nov 12 2012)
===================

* New example Gibbs sampler (Flavio Coelho)
* Ported sage interface to probability distributions
* Added odeiv2 support (Benni Hepp)

0.2 (May 13 2012)
=================

* Added Unittests (integrated from pyrexgsl)
* Added more examples (integrated from pyrexgsl)

0.1.2
=====

* Better setup.py interface

0.1.1
=====

* Install CythonGSL so that it can be cimported reliably.

0.1
===

* First public release
